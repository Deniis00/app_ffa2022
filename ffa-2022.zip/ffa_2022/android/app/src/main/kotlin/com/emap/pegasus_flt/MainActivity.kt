package com.emap.ffa_2022

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

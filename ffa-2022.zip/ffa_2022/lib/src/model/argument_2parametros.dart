class Parameters2Arguments {
  final int _tipo;
  final String _filtro;

  Parameters2Arguments(this._tipo, this._filtro);

  int get getTipo {
    return _tipo;
  }

  String get getFiltro {
    return _filtro;
  }

}